import os
# To use a global variable inside a function use the word "global" before

# declare these as global variables so they can be available throughout the program
accountNo = 0
CusName = " "
Mobile = 0
balance = 10000

def create_data_file():
    with open("Bank Data.txt", "w") as file:
        file.write("10000.00")

def read_balance():
    if not os.path.isfile("Bank Data.txt"):
        create_data_file()

    with open("Bank Data.txt", "r") as file:
        balance = float(file.readline())
    return balance

def write_balance(balance):
    with open("Bank Data.txt", "w") as file:
        file.write(str(balance)) 

def log_transaction(transaction):
    with open("Transaction Log.txt", "a") as file:
        file.write(transaction + "\n")

def createAccounts():
    global accountNo
    global CusName
    global Mobile
    global Bal
    accountNo = int(input("Enter account Number: "))
    if accountNo <= 0:
        print("Invalid Account number")
        return createAccounts()
        
    CusName = input("Enter Name: ")
    
    Mobile = int(input("Enter Mobile number: "))
    
def LogIn():
    username = input("Enter Username: ")
    password = input("Enter Password: ")
    print("Total balance: R", read_balance())
    
def Deposit():
    global balance 
    amount = float(input("How much would you like to deposit?: "))
    if amount <= 0:
        print("Invalid deposit amount!")
        return Deposit()
    
    balance = read_balance()
    balance += amount
    write_balance(balance)
    log_transaction("Deposit: R+{}".format(amount))
    print("Deposit successfull \n")
    print("Current balance: R{}".format(balance))
    print("Would you like to make another transaction? \n1.Yes \n 2.No")
    choice = int(input("Select option: "))
    if (choice==2):
      print("Thank you. Goodbye!")
      exit()
      
    elif(choice==1):
        print("1.Withdraw \n2.Deposit \n3.Check balance \n")
        choice = int(input("Select option: " ))

        if(choice==1):
            Withdraw()
     
        if(choice==2):
         Deposit()

        if(choice==3):
            display_balance()

def Withdraw():
    global balance
    amount = float(input("How much would you like to withdraw?: "))
    if amount <=0:
        print("Invalid withdrawal amount! \n")
        return Withdraw()

    balance = read_balance()
    if amount > balance:
        print("Insufficient funds! \n")
        return Withdraw()
    
    balance -= amount
    write_balance(balance)
    log_transaction("Withdrawal: R-{}".format(amount))
    print("Withdrawal Successful \n")
    print("Current balance: R{}".format(balance))
    print("Would you like to make another transaction? \n1.Yes \n2.No")
    choice = int(input("Select option: "))
    if (choice==2):
      print("Thank you. Goodbye!")
      
      
    elif(choice==1):
        print("1.Withdraw \n2.Deposit \n3.Check balance \n")
        choice = int(input("Select option: " ))

        if(choice==1):
            Withdraw()
     
        if(choice==2):
         Deposit()

        if(choice==3):
            display_balance()
              
def display_balance():
    balance = read_balance()
    print("Current balance: {}".format(balance))

def main():
    print("WELCOME TO SIMPLYTECH'S BANKING APP \n")

    while True:

        print("1.Create account \n2.LogIn \n") 
        choice = int(input("Select option: "))

        if(choice==1):
            createAccounts()

        elif(choice==2):
            LogIn()


        print("Would you like to make a transaction? \n1.Yes \n2.No \n")
        ch = int(input("Select option: " ))

        if(ch >=3):
            print("Invalid input \n")

        if(ch==2):
            print("Thank you for using this banking app. Goodbye! \n")
            break
    
        elif(ch==1):
            print("1.Withdraw \n2.Deposit \n3.Check balance \n")
            choose = int(input("Select option: " ))

        if(choose==1):
            Withdraw()
     
        if(choose==2):
         Deposit()

        if(choose==3):
            display_balance()

if __name__ == "__main__":
 main()

